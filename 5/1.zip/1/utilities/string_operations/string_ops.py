
def reverse_string(s):
    """Return the reverse of the input string."""
    return s[::-1]

def capitalize_string(s):
    """Capitalize the first letter of the input string."""
    return s.capitalize()
