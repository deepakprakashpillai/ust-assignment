name = input("Enter your name : ")
print(f"Hello {name}!")

#2.  Data Variety Show: Reading Different Inputs
age = int(input("Enter age : "))
print(f"{name} is {age} years old")

#3. String Magic: Formatting the Output
quote = "You are great"
print(name+", "+quote.upper()+"!!")

#4. String Formatting Bonanza: f-strings vs. format() 
print(f"{name}, {quote.upper()}!!!!!!")